dc_shell -64 -f generate_db.tcl | tee generate_db.log
