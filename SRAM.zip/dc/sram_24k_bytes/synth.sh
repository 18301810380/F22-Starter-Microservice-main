dc_shell -64 -f sram_24k_bytes.tcl | tee sram_24k_bytes.log
