pt_shell -file sram_24k_bytes.tcl > sram_24k_bytes.log &
