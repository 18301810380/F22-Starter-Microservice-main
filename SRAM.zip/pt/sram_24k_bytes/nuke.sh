rm *.log *.rpt *.fsdb *.sdf  
